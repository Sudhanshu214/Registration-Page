import 'package:flutter/material.dart';
//import 'package:registration/Screens/signupdetail.dart';
import 'package:registration/Widgets/background.dart';
import 'package:registration/Widgets/loginwidgets.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() {
    return _LoginPageState();
  }
}

class _LoginPageState extends State<LoginPage> {
  //int _selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    // void onItemTapped(int index) {
    //   setState(() {
    //     _selectedIndex = index;
    //   });
    //
    //   // Navigate based on the tapped index
    //   switch (index) {
    //     case 0:
    //       Navigator.push(
    //         context,
    //         MaterialPageRoute(builder: (ctx) =>const SignUpDetail()), // Replace with your page
    //       );
    //       break;
    //     case 1:
    //       Navigator.push(
    //         context,
    //         MaterialPageRoute(builder: (ctx) => const SignUpDetail()), // Replace with your page
    //       );
    //       break;
    //     case 2:
    //       Navigator.push(
    //         context,
    //         MaterialPageRoute(builder: (ctx) => const SignUpDetail()), // Replace with your page
    //       );
    //       break;
    //   }
    // }
    return GradientBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: const Text("L O G I N P A G E"),
          centerTitle: true,
          backgroundColor: Colors.blue,
        ),
        body: const LoginWidgets(),
          // bottomNavigationBar: BottomNavigationBar(
          //   items: const <BottomNavigationBarItem>[
          //     BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          //     BottomNavigationBarItem(icon: Icon(Icons.business), label: 'Business'),
          //     BottomNavigationBarItem(icon: Icon(Icons.school), label: 'School'),
          //   ],
          //   onTap: onItemTapped
          // ),

      ),
    );
  }
}
