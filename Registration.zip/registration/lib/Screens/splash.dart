import 'dart:async';
import 'package:flutter/material.dart';
import 'package:registration/Screens/login.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(
      const Duration(seconds: 2),
      () {
       // Navigator.pushNamed(context, '/first');
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (ctx) => const LoginPage(),),);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.lightGreen,
        child: const Center(
          child: Text(
            ' W E L C O M E ! ',
            style: TextStyle(
              fontSize: 34,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}
