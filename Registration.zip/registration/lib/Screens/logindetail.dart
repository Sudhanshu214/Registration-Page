import 'package:flutter/material.dart';
import 'package:registration/Widgets/login_detail_widgets.dart';
import 'package:registration/model/auth_validation_helper.dart';
import '../Widgets/background.dart';
// import 'login.dart';
// import 'package:photo_manager/photo_manager.dart';
// import 'package:flutter/services.dart';
// import 'package:permission_handler/permission_handler.dart';
//import 'package:permission_handler/permission_handler.dart';
//import 'package:registration/Screens/login.dart';
//import 'package:shared_preferences/shared_preferences.dart';
class LoginDetail extends StatefulWidget {
  const LoginDetail({super.key, required this.username});

  final String username;

  @override
  State<LoginDetail> createState() {
    return _LoginDetailState();
  }
}

class _LoginDetailState extends State<LoginDetail> {
  final AuthValidationHelper logInData = AuthValidationHelper();
  // List<AssetEntity> _mediaList = [];
  // bool isLoading = true;
  //
  // @override
  // void initState() {
  //   super.initState();
  //   WidgetsBinding.instance.addPostFrameCallback((_) async {
  //     await loadUserData();
  //     await _fetchMedia();
  //   });
  //   //loadUserPreferences();
  //   // WidgetsBinding.instance.addPostFrameCallback((_) async {
  //   //   await logInData.loadPreferences(widget.username);
  //   //   setState(() {
  //   //   });
  //   // });
  //   // Assuming you have already validated login and obtained the user's index
  // }
  //
  // // Future<void> loadUserPreferences() async {
  // //   await logInData.loadPreferences(widget.username);
  // //   setState(() {});
  // // }
  //
  // Future<void> loadUserData() async {
  //   List<Map<String, dynamic>> userList = await logInData.loadUserData();
  //   for (var user in userList) {
  //     if (user['username'] == widget.username) {
  //       setState(() {
  //         logInData.sharedSavedFirstname = user['firstname'];
  //         logInData.sharedSavedLastname = user['lastname'];
  //         logInData.sharedSavedPhonenumber = user['phonenumber'];
  //       });
  //       break;
  //     }
  //   }
  // }
  //
  // Future<void> _fetchMedia() async {
  //   var status = await Permission.photos
  //       .request(); // On Android 13+, this requests media permissions
  //   if (status.isGranted) {
  //     // Permission is granted, fetch media
  //     List<AssetPathEntity> albums = await PhotoManager.getAssetPathList(
  //       type: RequestType.image,
  //     );
  //     if (albums.isNotEmpty) {
  //       List<AssetEntity> media =
  //           await albums[0].getAssetListPaged(page: 0, size: 100);
  //       setState(() {
  //         _mediaList = media;
  //         isLoading = false;
  //       });
  //     }
  //   } else {
  //     // Permission was denied or not granted
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       const SnackBar(
  //         content: Text(
  //             'Permission denied. Please enable photo access in settings.'),
  //       ),
  //     );
  //     openAppSettings(); // Use permission handler method to open app settings
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    String enteredUsername = logInData.loginUsernameController.text;
    // final savedFirstname = logInData.firstnameController.text;
    // final savedLastname = logInData.lastnameController.text;
    // final savedUsername = logInData.usernameController.text;
    // final savedPhonenumber = logInData.phonenumberController.text;
    // final savedPassword = logInData.passwordController.text;
    // setState(() {
    //   logInData.loadFirstname();
    // });
    return GradientBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: const Text(
            "D E T A I L S  P A G E",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          centerTitle: true,
          backgroundColor: Colors.blue,
        ),
        body: LoginDetailWidgets(username: enteredUsername),
        // body: Column(
        //   //mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //   //crossAxisAlignment: CrossAxisAlignment.start,
        //   children: [
        //     const Text(
        //       'Login Details',
        //       style: TextStyle(
        //         fontSize: 50,
        //         fontWeight: FontWeight.bold,
        //         color: Colors.orangeAccent,
        //       ),
        //     ),
        //     Expanded(
        //       child: Center(
        //         child: Column(
        //           mainAxisAlignment: MainAxisAlignment.center,
        //           children: [
        //             Text(
        //               'Your First name is ${logInData.sharedSavedFirstname}',
        //               //{logInData.sharedSavedFirstname}
        //               style: const TextStyle(
        //                 fontSize: 20,
        //                 fontWeight: FontWeight.bold,
        //                 color: Colors.tealAccent,
        //               ),
        //             ),
        //             Text(
        //               'Your Last name is ${logInData.sharedSavedLastname}',
        //               style: const TextStyle(
        //                 fontSize: 20,
        //                 fontWeight: FontWeight.bold,
        //                 color: Colors.tealAccent,
        //               ),
        //             ),
        //             Text(
        //               'Your Phone Number is ${logInData.sharedSavedPhonenumber}',
        //               style: const TextStyle(
        //                 fontSize: 20,
        //                 fontWeight: FontWeight.bold,
        //                 color: Colors.tealAccent,
        //               ),
        //             ),
        //             const Text(
        //               'All images from Gallery',
        //               style: TextStyle(
        //                 fontSize: 30,
        //                 fontWeight: FontWeight.bold,
        //                 color: Colors.black,
        //               ),
        //             ),
        //             Container(
        //               margin: const EdgeInsets.all(9),
        //               height: 400,
        //               decoration: BoxDecoration(
        //                 border: Border.all(
        //                   color: Colors.black, // Set the border color here
        //                   width: 2.0, // Set the border width here
        //                 ),
        //                 borderRadius: const BorderRadius.all(
        //                   Radius.circular(20), // Set the desired radius here
        //                 ),
        //               ),
        //               child: isLoading
        //                   ? const Center(child: CircularProgressIndicator())
        //                   : GridView.builder(
        //                       gridDelegate:
        //                           const SliverGridDelegateWithFixedCrossAxisCount(
        //                         crossAxisCount: 3,
        //                         crossAxisSpacing: 4,
        //                         mainAxisSpacing: 4,
        //                       ),
        //                       itemCount: _mediaList.length,
        //                       itemBuilder: (context, index) {
        //                         return FutureBuilder<Uint8List?>(
        //                           future: _mediaList[index].thumbnailData,
        //                           builder: (context, snapshot) {
        //                             final bytes = snapshot.data;
        //                             if (bytes == null) {
        //                               return const Center(
        //                                 child: Center(child: CircularProgressIndicator()),
        //                               );
        //                             }
        //                             return Image.memory(
        //                               bytes,
        //                               fit: BoxFit.cover,
        //                             );
        //                           },
        //                         );
        //                       },
        //                     ),
        //             ),
        //           ],
        //         ),
        //       ),
        //     ),
        //     Padding(
        //       padding: const EdgeInsets.all(8.0),
        //       child: ElevatedButton(
        //         onPressed: () {
        //           Navigator.pushReplacement(
        //             context,
        //             MaterialPageRoute(
        //               builder: (ctx) => const LoginPage(),
        //             ),
        //           );
        //           logInData.loginClearData();
        //         },
        //         child: const Text('Log Out'),
        //       ),
        //     ),
        //   ],
        // ),
      ),
    );
  }
}
