import 'package:flutter/material.dart';
import 'package:registration/Widgets/background.dart';
import 'package:registration/Widgets/signupwidgets.dart';

class SignUpDetail extends StatefulWidget {
  const SignUpDetail({super.key});

  @override
  State<SignUpDetail> createState() {
    return _SignUpDetailState();
  }
}

class _SignUpDetailState extends State<SignUpDetail> {
  @override
  Widget build(BuildContext context) {
    return GradientBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: const Text('S I G N U P P A G E'),
          centerTitle: true,
          backgroundColor: Colors.blue,
        ),
        body: const SignUpWidgets(),
      ),
    );
  }
}
