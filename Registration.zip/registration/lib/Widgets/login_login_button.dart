import 'package:flutter/material.dart';
import 'package:registration/model/auth_validation_helper.dart';
import '../Screens/logindetail.dart';

class LoginLoginButton extends StatelessWidget {
  const LoginLoginButton({super.key});

  Future<void> loginLoginPage(context) async {
    AuthValidationHelper authValidationHelper = AuthValidationHelper();
    String enteredUsername = authValidationHelper.loginUsernameController.text;

    if (await authValidationHelper.validateLogin(enteredUsername)) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (ctx) => LoginDetail(username: enteredUsername),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Invalid username or password")),
      );
    }

  }

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () {
        loginLoginPage(context);
      },
      child: const Text("Login"),
    );
  }
}
