import 'package:flutter/material.dart';
import 'package:registration/model/auth_validation_helper.dart';
//import '../Screens/signupdetail.dart';
import 'login_login_button.dart';

class LoginWidgets extends StatefulWidget {
  const LoginWidgets({
    super.key,
  });

  @override
  State<LoginWidgets> createState() => _LoginWidgetsState();
}

class _LoginWidgetsState extends State<LoginWidgets> {
  final AuthValidationHelper logInData = AuthValidationHelper();

  bool _isPasswordVisible = false;

  @override
  Widget build(BuildContext context) {
    return _page(context);
  }

  Widget _page(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.login_rounded,
              size: 100,
              color: Colors.white,
            ),
            Padding(
              padding: const EdgeInsets.only(top: 40, bottom: 20),
              child: _inputField("email", logInData.loginUsernameController),
            ),
            _inputField("password", logInData.loginPasswordController,
                isPassword: true),
            const Padding(
                padding: EdgeInsets.only(top: 30, bottom: 20),
                child: //Navigator.pushNamed(context, '/third');
              LoginLoginButton()
                // _loginButton(context),
                ),
            _signUpButton(context),
          ],
        ),
      ),
    );
  }

  Widget _signUpButton(BuildContext context) {
    return ElevatedButton(
      onPressed: () {
        Navigator.pushNamed(context, '/second');
        // Navigator.push(
        //   context,
        //   MaterialPageRoute(
        //     builder: (ctx) => const SignUpDetail(),
        //   ),
        // );
        logInData.signClearData();
      },
      child: const Text('Sign up'),
    );
  }

  Widget _inputField(
      String hintText,
      TextEditingController controller, {
        bool isPassword = false,
        TextInputType keyboardType = TextInputType.text,
        TextCapitalization textCapitalization = TextCapitalization.none,
      }) {
    return TextField(
      style: const TextStyle(color: Colors.white),
      controller: controller,
      keyboardType: keyboardType,
      textCapitalization: textCapitalization,
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: const TextStyle(color: Colors.white),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(
            color: Colors.white,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(
            color: Colors.white,
            width: 3,
          ),
        ),
        suffixIcon: isPassword
            ? IconButton(
          icon: Icon(
              _isPasswordVisible ? Icons.visibility : Icons.visibility_off,
              color: Colors.white),
          onPressed: () {
            setState(() {
              _isPasswordVisible = !_isPasswordVisible;
            });
          },
        )
            : null,
      ),
      obscureText: isPassword && !_isPasswordVisible,
    );
  }
}
