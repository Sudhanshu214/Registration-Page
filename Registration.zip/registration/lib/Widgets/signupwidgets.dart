import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
//import 'package:registration/Screens/login.dart';
import 'package:registration/model/auth_validation_helper.dart';

import '../Screens/login.dart';

class SignUpWidgets extends StatefulWidget {
  const SignUpWidgets({
    super.key,
  });

  @override
  State<SignUpWidgets> createState() => _SignUpWidgetsState();
}

class _SignUpWidgetsState extends State<SignUpWidgets> {
  final AuthValidationHelper signUpData = AuthValidationHelper();
  bool _isPasswordVisible = false;

  @override
  Widget build(BuildContext context) {
    return _page(context);
  }

  Widget _page(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: ListView(
          children: [
            const SizedBox(
              height: 20,
            ),
            const Align(
              alignment: Alignment.topCenter,
              child: Icon(
                Icons.save_alt,
                size: 100,
                color: Colors.white,
              ),
            ),
            const SizedBox(
              height: 100,
            ),
            _inputField(
                hintlabel: 'first name',
                controller: signUpData.firstnameController),
            const SizedBox(
              height: 20,
            ),
            _inputField(
                hintlabel: 'last name',
                controller: signUpData.lastnameController),
            //),
            const SizedBox(
              height: 20,
            ),
            _inputField(
                hintlabel: 'email', controller: signUpData.usernameController),
            //),
            const SizedBox(
              height: 20,
            ),
            _inputField(
                hintlabel: 'phone number',
                controller: signUpData.phonenumberController),
            //),
            const SizedBox(
              height: 20,
            ),
            _inputField(
                hintlabel: 'create password',
                controller: signUpData.passwordController,
                isPassword: true),
            const SizedBox(
              height: 40,
            ),
            ElevatedButton(
              onPressed: () {
                if (!validateFields(context)) {
                  return;
                }
                signUpData.saveData();
                //Navigator.pushNamed(context, '/first');
                Navigator.pop(
                  context,
                  MaterialPageRoute(
                    builder: (ctx) => const LoginPage(),
                  ),
                );
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

//   Widget _inputField(String hintlabel, TextEditingController controller,
//       {bool isEmail = false}) {
//     // Add isEmail parameter
//     return TextFormField(
//       style: const TextStyle(color: Colors.white),
//       controller: controller,
//       keyboardType: isEmail ? TextInputType.emailAddress : TextInputType.text,
//       textCapitalization: TextCapitalization.none,
//       decoration: InputDecoration(
//         labelText: hintlabel,
//         labelStyle: const TextStyle(color: Colors.white),
//         focusedBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(10),
//           borderSide: const BorderSide(
//             color: Colors.white,
//             width: 3,
//           ),
//         ),
//         enabledBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(10),
//           borderSide: const BorderSide(
//             color: Colors.white,
//             //width: 2,
//           ),
//         ),
//         suffixIcon: isEmail
//             ? const Icon(
//                 Icons.email_outlined,
//                 color: Colors.white,
//               )
//             : null,
//       ),
//       validator: (value) => validateField(value, hintlabel,
//           isEmail: isEmail), // Use validateField function
//     );
//   }
//
//   // Widget _inputField(String hintlabel, TextEditingController controller) {
//   //   return TextFormField(
//   //     style: const TextStyle(color: Colors.white),
//   //     controller: controller,
//   //     inputFormatters: hintlabel.toLowerCase() == 'first name' ||
//   //             hintlabel.toLowerCase() == 'last name'
//   //         ? [FilteringTextInputFormatter.allow(RegExp('[a-zA-Z]'))]
//   //         : null,
//   //     keyboardType: hintlabel.toLowerCase() == 'email'
//   //         ? TextInputType.emailAddress
//   //         : TextInputType.text,
//   //     textCapitalization: TextCapitalization.none,
//   //     decoration: InputDecoration(
//   //       labelText: hintlabel,
//   //       labelStyle: const TextStyle(color: Colors.white),
//   //       focusedBorder: OutlineInputBorder(
//   //         borderRadius: BorderRadius.circular(10),
//   //         borderSide: const BorderSide(
//   //           color: Colors.white,
//   //           width: 3,
//   //         ),
//   //       ),
//   //       enabledBorder: OutlineInputBorder(
//   //         borderRadius: BorderRadius.circular(10),
//   //         borderSide: const BorderSide(
//   //           color: Colors.white,
//   //           //width: 2,
//   //         ),
//   //       ),
//   //       suffixIcon: hintlabel.toLowerCase() == 'email'
//   //           ? const Icon(
//   //               Icons.email_outlined,
//   //               color: Colors.white,
//   //             )
//   //           : null,
//   //     ),
//   //     validator: hintlabel.toLowerCase() == 'email'
//   //         ? (value) {
//   //             if (value == null || value.isEmpty) {
//   //               return 'Please enter your email';
//   //             } else if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
//   //               return 'Please enter a valid email address';
//   //             }
//   //             return null;
//   //           }
//   //         : null,
//   //   );
//   // }
//
// ////
//
//   Widget _inputField1(String hintlabel, TextEditingController controller) {
//     return TextFormField(
//       keyboardType: TextInputType.phone,
//       style: const TextStyle(color: Colors.white),
//       controller: controller,
//       inputFormatters: [
//         FilteringTextInputFormatter.digitsOnly,
//       ],
//       decoration: InputDecoration(
//         labelText: hintlabel,
//         labelStyle: const TextStyle(color: Colors.white),
//         focusedBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(10),
//           borderSide: const BorderSide(
//             color: Colors.white,
//             width: 3,
//           ),
//         ),
//         enabledBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(10),
//           borderSide: const BorderSide(
//             color: Colors.white,
//             //width: 2,
//           ),
//         ),
//         suffixIcon: hintlabel.toLowerCase() == 'phone number'
//             ? const Icon(
//                 Icons.phone,
//                 color: Colors.white,
//               )
//             : null,
//       ),
//     );
//   }
//
//   Widget _inputField2(String hintText, TextEditingController controller,
//       {bool isPassword = false}) {
//     return TextField(
//       style: const TextStyle(color: Colors.white),
//       controller: controller,
//       decoration: InputDecoration(
//         hintText: hintText,
//         hintStyle: const TextStyle(color: Colors.white),
//         enabledBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(10),
//           borderSide: const BorderSide(
//             color: Colors.white,
//             //width: 3,
//           ),
//         ),
//         focusedBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(10),
//           borderSide: const BorderSide(
//             color: Colors.white,
//             width: 3,
//           ),
//         ),
//         suffixIcon: isPassword
//             ? IconButton(
//                 icon: Icon(
//                     _isPasswordVisible
//                         ? Icons.visibility
//                         : Icons.visibility_off,
//                     color: Colors.white),
//                 onPressed: () {
//                   setState(() {
//                     _isPasswordVisible = !_isPasswordVisible;
//                   });
//                 },
//               )
//             : null,
//       ),
//       obscureText: isPassword && !_isPasswordVisible,
//     );
//   }

  Widget _inputField({
    required String hintlabel,
    required TextEditingController controller,
    bool isEmail = false,
    bool isPhone = false,
    bool isPassword = false,
  }) {
    return TextFormField(
      style: const TextStyle(color: Colors.white),
      controller: controller,
      keyboardType: isEmail
          ? TextInputType.emailAddress
          : isPhone
              ? TextInputType.phone
              : TextInputType.text,
      inputFormatters: isPhone
          ? [FilteringTextInputFormatter.digitsOnly]
          : (hintlabel.toLowerCase() == 'first name' ||
                  hintlabel.toLowerCase() == 'last name')
              ? [FilteringTextInputFormatter.allow(RegExp('[a-zA-Z]'))]
              : null,
      obscureText: isPassword && !_isPasswordVisible,
      decoration: InputDecoration(
        labelText: hintlabel,
        labelStyle: const TextStyle(color: Colors.white),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(
            color: Colors.white,
            width: 3,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(
            color: Colors.white,
          ),
        ),
        suffixIcon: isEmail
            ? const Icon(
                Icons.email_outlined,
                color: Colors.white,
              )
            : isPhone
                ? const Icon(
                    Icons.phone,
                    color: Colors.white,
                  )
                : isPassword
                    ? IconButton(
                        icon: Icon(
                          _isPasswordVisible
                              ? Icons.visibility
                              : Icons.visibility_off,
                          color: Colors.white,
                        ),
                        onPressed: () {
                          setState(() {
                            _isPasswordVisible = !_isPasswordVisible;
                          });
                        },
                      )
                    : null,
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter $hintlabel';
        } else if (isEmail && !RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
          return 'Please enter a valid email address';
        }
        return null;
      },
    );
  }

  bool validateFields(BuildContext context) {
    bool isValid = true;

    if (signUpData.firstnameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter your first name'),
        ),
      );
      isValid = false;
    }

    if (signUpData.lastnameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter your last name'),
        ),
      );
      isValid = false;
    }

    if (signUpData.usernameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter your email'),
        ),
      );
      isValid = false;
    }

    if (signUpData.phonenumberController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter your phone number'),
        ),
      );
      isValid = false;
    }

    if (signUpData.passwordController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please create your password'),
        ),
      );
      isValid = false;
    }

    return isValid;
  }

// String? validateField(String? value, String hintlabel,
//     {bool isEmail = false}) {
//   if (value == null || value.isEmpty) {
//     return 'Please enter $hintlabel';
//   }
//   if (isEmail &&
//       !RegExp(
//         r'^[\w-]+(\.[\w-]+)*@[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)*(\.[a-zA-Z]{2,})$',
//       ).hasMatch(value)) {
//     return 'Please enter a valid email address';
//   }
//   return null;
// }
}
