import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:photo_manager/photo_manager.dart';

class GalleryImageLoader extends StatefulWidget {
  const GalleryImageLoader({super.key});

  @override
  State<GalleryImageLoader> createState() => _GalleryImageLoaderState();
}

class _GalleryImageLoaderState extends State<GalleryImageLoader> {
  List<AssetEntity> _mediaList = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await _fetchMedia();
    });
  }

  Future<void> _fetchMedia() async {
    var status = await Permission.photos.request();

    if(Platform.isIOS){
      List<AssetPathEntity> albums = await PhotoManager.getAssetPathList(
        type: RequestType.image,
      );
      if (albums.isNotEmpty) {
        List<AssetEntity> media = await albums[0].getAssetListPaged(page: 0, size: 100);
        setState(() {
          _mediaList = media;
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No images found in gallery.')),
        );
      }
      return;
    }

    if (status.isGranted) {
      List<AssetPathEntity> albums = await PhotoManager.getAssetPathList(
        type: RequestType.image,
      );

      if (albums.isNotEmpty) {
        List<AssetEntity> media = await albums[0].getAssetListPaged(page: 0, size: 100);
        setState(() {
          _mediaList = media;
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No images found in gallery.')),
        );
      }
    } else if (status.isPermanentlyDenied) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Permission denied. Please enable photo access in settings.')),
      );
      openAppSettings();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Photo access denied')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(9),
      height: 200,
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.black,
          width: 2.0,
        ),
        borderRadius: const BorderRadius.all(
          Radius.circular(20),
        ),
      ),
      child: isLoading
          ? const Center(child: CircularProgressIndicator())
          : _mediaList.isEmpty
          ? const Center(
        child: Text(
          'No images available',
          style: TextStyle(fontSize: 16, color: Colors.black),
        ),
      )
          : GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 4,
          mainAxisSpacing: 4,
        ),
        itemCount: _mediaList.length,
        itemBuilder: (context, index) {
          return FutureBuilder<Uint8List?>(
            future: _mediaList[index].thumbnailData,
            builder: (context, snapshot) {
              final bytes = snapshot.data;
              if (bytes == null) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              }
              return Image.memory(
                bytes,
               // fit: BoxFit.cover,
              );
            },
          );
        },
      ),
    );
  }
}
