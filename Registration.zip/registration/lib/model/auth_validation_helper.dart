import 'dart:core';
import 'dart:io';
import 'dart:convert';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/material.dart';
//import 'package:flutter/services.dart';
//import 'package:shared_preferences/shared_preferences.dart';

class AuthValidationHelper {
  static final AuthValidationHelper _instance = AuthValidationHelper._internal();

  factory AuthValidationHelper() {
    return _instance;
  }

  AuthValidationHelper._internal();

  // Controllers for sign-up data
  final TextEditingController firstnameController = TextEditingController();
  final TextEditingController lastnameController = TextEditingController();
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController phonenumberController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  // Controllers for login data
  final TextEditingController loginUsernameController = TextEditingController();
  final TextEditingController loginPasswordController = TextEditingController();

  // Variables to hold the saved data
  String? sharedSavedFirstname;
  String? sharedSavedLastname;
  String? sharedSavedPhonenumber;
  // String? sharedSavedUsername;
  // String? sharedSavedPassword;
  // String savedFirstname = '';
  // String savedLastname = '';
  // String savedUsername = '';
  // String savedPhonenumber = '';
  // String savedPassword = '';
  // String firstName = "";
  // String lastName = "";
  // String phoneNumber = "";
  // String? _savedFirstname;
  // String? _savedLastname;
  // String? _savedUsername;
  // String? _savedPhonenumber;
  // String? _savedPassword;


  // Save the sign-up data

  Future<void> saveData() async {
    ///Saving data in json file now
    //creating a map
    try {
      final directory = await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/data.json');
      List<dynamic> userList = [];

      if (await file.exists()) {
        //await file.writeAsString("[]");
        String jsonData = await file.readAsString();
        if(jsonData.isNotEmpty){
          userList = jsonDecode(jsonData);
        }
      }
      Map<String, String> newUser = {
        'firstname': firstnameController.text,
        'lastname': lastnameController.text,
        'username': usernameController.text,
        'phonenumber': phonenumberController.text,
        'password': passwordController.text,
      };
      //add new user to the list
      userList.add(newUser);
      //convert the updated list
      String updatedData = jsonEncode(userList);
      // write the updated json data
      await file.writeAsString(updatedData);

      //print('user data saved successfully');
    } catch (e) {
     //print(e);
    }

    ///Saving data in single  string using ',' separated
    // savedFirstname += (firstnameController.text.isNotEmpty
    //     ? "${firstnameController.text},"
    //     : "");
    // savedLastname += (lastnameController.text.isNotEmpty
    //     ? "${lastnameController.text},"
    //     : "");
    // savedUsername += (usernameController.text.isNotEmpty
    //     ? "${usernameController.text},"
    //     : "");
    // savedPhonenumber += (phonenumberController.text.isNotEmpty
    //     ? "${phonenumberController.text},"
    //     : "");
    // savedPassword += (passwordController.text.isNotEmpty
    //     ? "${passwordController.text},"
    //     : "");

    // savedFirstname = firstnameController.text;
    // savedLastname = lastnameController.text;
    // savedUsername = usernameController.text;
    // savedPhonenumber = phonenumberController.text;
    // savedPassword = passwordController.text;

    //read data using shared preference
    /// data stored using shared preference
    // final SharedPreferences prefs = await SharedPreferences.getInstance();
    // String username = usernameController.text;
    // await prefs.setString('${username}_firstname', firstnameController.text);
    // await prefs.setString('${username}_lastname', lastnameController.text);
    // await prefs.setString('${username}_phonenumber', phonenumberController.text);
    // await prefs.setString('${username}_username', usernameController.text);
    // await prefs.setString('${username}_password', passwordController.text);
  }

  ///loading all users data
  Future<List<Map<String, dynamic>>> loadUserData() async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      //print(directory);
      final file = File('${directory.path}/data.json');
      //final file = File('assets/data.json');
      //print(file);
      if (await file.exists()) {
        String jsonData = await file.readAsString();
        if(jsonData.isNotEmpty){
          //created list again
          List<dynamic> userList = jsonDecode(jsonData);
          return List<Map<String, dynamic>>.from(userList);
        }else{
          //print('no user data found');
          return [];
        }
      } else {
       // print('no user data');
        return [];
      }
    } catch (e) {
     // print('error loading user data $e');
      return [];
    }
  }

  ///  Future shared preference method
  // Future<void> loadPreferences(String username) async {
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   sharedSavedFirstname = prefs.getString('${username}_firstname');
  //   sharedSavedLastname = prefs.getString('${username}_lastname');
  //   sharedSavedUsername = prefs.getString('${username}_username');
  //   sharedSavedPhonenumber = prefs.getString('${username}_phonenumber');
  //   sharedSavedPassword = prefs.getString('${username}_password');
  //  // print(sharedSavedFirstname = prefs.getString('${username}_firstname'));
  // }
  /// Find the index of the user with matching email and password in single string values
  // int findPersonIndex(String email, String password) {
  //   int index = 0;
  //   int start = 0;
  //
  //   for (int i = 0; i < savedUsername.length; i++) {
  //     if (savedUsername[i] == ',') {
  //       String currentEmail = savedUsername.substring(start, i);
  //       String currentPassword = extractData(savedPassword, index);
  //
  //       if (currentEmail == email && currentPassword == password) {
  //         return index; // Match found
  //       }
  //       start = i + 1;
  //       index++;
  //     }
  //   }
  //   return -1; // No match found
  // }

  // Extract data for a specific person based on index
  /// Extract data in single string values
  // String extractData(String dataString, int index) {
  //   print(dataString);
  //   int start = 0;
  //   int commaCount = 0;
  //
  //   for (int i = 0; i < dataString.length; i++) {
  //     if (dataString[i] == ',') {
  //       if (commaCount == index) {
  //         return dataString.substring(start, i);
  //       }
  //       start = i + 1;
  //       commaCount++;
  //     }
  //   }
  //   return "";
  // }

  // Validate login data

  //// ValidateLogin
  validateLogin(String username) async {
    ///Validating directly from the json file
    try {
      List<Map<String, dynamic>> userlist = await loadUserData();
      for (var user in userlist) {
        if (user['username'] == username &&
            user['password'] == loginPasswordController.text) {
          return true;
        }
      }
      return false;
    } catch (e) {
      //print('error validating login $e');
      return false;
    }

    ///validated using shared preference
    // SharedPreferences prefs = await SharedPreferences.getInstance();
    // var name = prefs.getString('${username}_username');
    // var pwd = prefs.getString('${username}_password');
    // return  name == loginUsernameController.text &&
    // pwd == loginPasswordController.text;
    ///validating logic when using single string method
    // bool validateLogin() {
    //   int personIndex = findPersonIndex(
    //       loginUsernameController.text, loginPasswordController.text);
    //
    //   if (personIndex != -1) {
    //     firstName = extractData(savedFirstname, personIndex);
    //     lastName = extractData(savedLastname, personIndex);
    //     phoneNumber = extractData(savedPhonenumber, personIndex);
    //
    //     print("Logged in as: $firstName $lastName");
    //     print("Phone: $phoneNumber");
    //
    //     loginClearData();
    //     return true;
    //   } else {
    //     print("Login failed: Invalid email or password");
    //     return false;
    //   }
    // }
    ///Simple validating logic for one value
    // Validate login data
    // bool validateLogin() {
    //   print(_savedFirstname);
    //   print(_savedLastname);
    //   print(_savedPhonenumber);
    //   print(_savedUsername);
    //   print(loginUsernameController.text);
    //   print(_savedPassword);
    //   print(loginPasswordController.text);
    //   return _savedUsername == loginUsernameController.text &&
    //       _savedPassword == loginPasswordController.text;
    // }

    // Method to clear all data
  }

  void clearData() {
    loginClearData();
    signClearData();
    // _savedFirstname = null;
    // _savedLastname = null;
    // _savedUsername = null;
    // _savedPhonenumber = null;
    // _savedPassword = null;
  }

  void loginClearData() {
    loginUsernameController.clear();
    loginPasswordController.clear();
  }

  void signClearData() {
    firstnameController.clear();
    lastnameController.clear();
    usernameController.clear();
    phonenumberController.clear();
    passwordController.clear();
  }

  bool checkData() {
    return firstnameController.text.isNotEmpty &&
        lastnameController.text.isNotEmpty &&
        usernameController.text.isNotEmpty &&
        phonenumberController.text.isNotEmpty &&
        passwordController.text.isNotEmpty;
    // return savedFirstname.toString().isNotEmpty &&
    //     savedLastname.toString().isNotEmpty &&
    //     savedUsername.toString().isNotEmpty &&
    //     savedPhonenumber.toString().isNotEmpty &&
    //     savedPassword.toString().isNotEmpty;
  }
}
