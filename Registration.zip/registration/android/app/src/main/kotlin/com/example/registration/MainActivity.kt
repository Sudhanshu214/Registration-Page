package com.example.registration

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
